---
title: อุปกรณ์ชาร์จ
category: charger
description: หัวชาร์จ, สายชาร์จ, Wireless Charger มาตรฐานสากล
image: ""
specs:
  - Fast Charging
  - รับรองมาตรฐาน
  - ปลอดภัย 100%
is_oem: true
order: 2
---
