---
site_title: Full 9 Company Limited | บริษัท ฟูล 9 จำกัด
site_description: ผู้เชี่ยวชาญด้านอุปกรณ์เสริมโทรศัพท์และ Gadget รับผลิตแบบ OEM
colors:
  primary: "#1B4D3E"
  secondary: "#D4AF37"
  background: "#FFFFFF"
  text: "#1A1A1A"
favicon: ""
logo: ""
---
